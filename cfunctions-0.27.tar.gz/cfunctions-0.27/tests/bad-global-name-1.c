// options: -g bad-global-name-1 -i
// error: will be overwritten by 

int silly;
