#include "ok-verbatim.h"

fuga
main ()
{
  return func();
}
