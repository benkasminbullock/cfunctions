#include "ok-multi-array.h"

int main()
{
  return hugh(mung[1][2]);
}
