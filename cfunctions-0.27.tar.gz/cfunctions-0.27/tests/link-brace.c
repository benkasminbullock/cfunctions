#include "ok-brace.h"

int jubbins;

int main()
{
  return tellytubby (1,2,3,'}');
}
