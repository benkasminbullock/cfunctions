#include <stdio.h>
#include "ok-enum.h"

int
main()
{
  printf ( "%d\n", enum_func ( c ));
  return 0;
}
