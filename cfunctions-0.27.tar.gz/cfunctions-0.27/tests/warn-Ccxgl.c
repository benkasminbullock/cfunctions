// options: -C -c -x
// warning: options are useless when C preprocessing

#if 0
hallo!
#endif
