// options: -l jub.c
// warning: looks like a C file name

int z;
