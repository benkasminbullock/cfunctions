/* Multidimensional array. */

#ifdef HEADER
#define MUNG 10
#endif

#include "ok-multi-array.h"

int mung[MUNG][MUNG];

int hugh(unsigned gus)
{
  return mung[gus][gus];
}
