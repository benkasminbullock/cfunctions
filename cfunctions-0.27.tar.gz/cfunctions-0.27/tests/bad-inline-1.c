// error: an external variable cannot be `inline'.

INLINE int jubs;
