// warning: does not look like a C file

// options: funky_junk.notc
