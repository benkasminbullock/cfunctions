#include "ok-global-macro.h"

// options: -G GLOBAL_MACRO_REPLACEMENT

#ifdef GLOBAL_MACRO_REPLACEMENT

/* copy the rest of this verbatim */

int x, y, z;

#endif
