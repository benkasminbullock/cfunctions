#include <stdlib.h>
#include "ok-x.h"

int main(int argc, char ** argv)
{
  print_msg ( "all the arguments are ignored.%d%d%d%d\n",1,2,3,4);
  printf ( "%d\n", jubbins());
  hubajub();
  bye_bye();
  exit (0);
}
