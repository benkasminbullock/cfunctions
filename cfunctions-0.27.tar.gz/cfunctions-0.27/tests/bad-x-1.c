// error: bad print format

PRINT_FORMAT (1, 2, 3) jubbins ()
{
  return;
}
