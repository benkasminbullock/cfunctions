// options: -l jub -g jub
// error: the same as the global name

int jubbls;
