// error: `;' in enum list.

enum fub { @ jub; } juble;
