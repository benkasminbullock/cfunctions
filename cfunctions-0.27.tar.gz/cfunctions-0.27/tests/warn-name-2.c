// options: -g jub.c
// warning: looks like a C file name

int zz;
