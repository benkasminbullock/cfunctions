// options: -C -P -DGUBBINS

// tags: jub

#ifdef GUBBINS

int jub (int x) { return x* 33; }

#endif

