#include "jubbins.h"

int
main ()
{
  jubbins = 0;
  return 0;
}
