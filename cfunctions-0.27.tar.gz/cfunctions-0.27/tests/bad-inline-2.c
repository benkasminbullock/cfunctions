// error: INLINE inside verbatim

#ifdef HEADER
INLINE int func(int a) { return a;}
#endif
