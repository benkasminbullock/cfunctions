// options: -L YOCAL
// tags: jub rub

#include "ok-local-macro.h"

#ifdef YOCAL

int jub;
int rub;

#endif
