// options: --wrap funky --individual
// warning: will be ignored because output files
