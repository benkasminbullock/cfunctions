// tags: a b c d e f

#include "ok-external.h"


int a = 99, b[33], c[99*44], * d, ** e, *** f;
