#include "ok-copy-c-ex.h"

int
main ()
{
  return mubbins(33);
}
