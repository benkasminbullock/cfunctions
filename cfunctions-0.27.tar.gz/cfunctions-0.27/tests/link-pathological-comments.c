// gcc_opt: -Wno-comment
#include "ok-pathological-comments.h"
int main ()
{
    return 0;
}
