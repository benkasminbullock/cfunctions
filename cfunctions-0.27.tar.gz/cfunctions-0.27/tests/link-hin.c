#include "hin-test.h"

int main()
{
  return frog(0);
}

