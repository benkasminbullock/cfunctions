// options: -c -x -k

#include "ok-copy-c-ex.h"

NO_SIDE_FX int mubbins (int x)
{
  return x * x;
}
