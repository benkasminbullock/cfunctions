// options: -i -s
// warning: static functions will be written to header
int s;
