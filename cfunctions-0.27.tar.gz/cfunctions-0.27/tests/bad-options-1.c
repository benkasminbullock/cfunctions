// options: -l jub -i
// error: option `--local' is incompatible with option `--individual'
