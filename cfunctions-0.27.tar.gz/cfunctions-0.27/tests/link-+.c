#include "ok-+.h"

int main()
{
  plus++;
  return plus;
}
