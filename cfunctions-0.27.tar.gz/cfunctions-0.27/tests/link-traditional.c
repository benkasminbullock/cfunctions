#define BLOATO(a) a
#include "ok-traditional.h"

/* just for some people who like this character: */



int main(int argc, char ** argv)
{
  if (argc)
    jub (2, 'a', 'b', 'c', argv[1], 1, 2, 3);
  return 44;
}

