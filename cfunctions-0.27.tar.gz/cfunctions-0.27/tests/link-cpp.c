// options: -DJUBINS

#include "ok-cpp.h"

/* It is quite hard to know exactly how to test this. */

int
main()
{
  return 0;
}
