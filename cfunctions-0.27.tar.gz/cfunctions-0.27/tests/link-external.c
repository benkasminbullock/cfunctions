#include "ok-external.h"

int
main()
{
return 0;
}
