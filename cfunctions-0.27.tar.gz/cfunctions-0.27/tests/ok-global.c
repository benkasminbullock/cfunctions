// tags: error jubbins x pork rubadub

// options: -g jubbins -i --backup

#include "jubbins.h"

typedef int rubadub;

#ifdef HEADER

int hog ( int q );

extern int pork;

#if 0

disastrous error;

#endif /* 0 */

typedef int x;

int jubbins;

#endif
