#include <stdio.h>

// gcc_opt: -O -Winline

#include "ok-c-string.h"

int main ()
{
    printf ( "%s %s %s %s\n", a, b, c, d);
    return 0;
}
