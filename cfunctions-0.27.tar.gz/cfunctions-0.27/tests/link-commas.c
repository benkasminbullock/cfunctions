#include "ok-commas.h"

int main ()
{
  stingray(1);
  monkfish(2);
  junkfish(3);
  return 0;
}
