#include "ok-global-macro.h"

int
main ()
{
  return x+y+z;
  /* silly stuff */;
}
