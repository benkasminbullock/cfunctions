// options: -i --advert heebygeeby
// warning: cannot find 

int q;
