#include "ok-local-macro.h"

int
main ()
{
  return jub + rub;
  /* silly stuff */;
}
