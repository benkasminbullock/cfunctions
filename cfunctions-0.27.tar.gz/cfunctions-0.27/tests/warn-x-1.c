// warning: no side effects and void return value

NO_SIDE_FX void silly_function ()
{
  return;
}
