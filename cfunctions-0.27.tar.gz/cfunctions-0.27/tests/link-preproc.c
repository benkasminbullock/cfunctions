// options: -DGUBBINS

#include "ok-preproc.h"

int main()
{
  return jub (99);
}

