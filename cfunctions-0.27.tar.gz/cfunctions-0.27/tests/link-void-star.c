#include <stdio.h>

#include "ok-void-star.h"

int
main()
{
  printf ( "%p\n", r(3));
  return 0;
}
